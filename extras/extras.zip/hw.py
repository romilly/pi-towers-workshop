from microbit import *

display.scroll('Hello World')