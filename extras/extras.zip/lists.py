from microbit import *

clocks = [Image.CLOCK12,
          Image.CLOCK1,
          Image.CLOCK2,
          Image.CLOCK3,
          Image.CLOCK4,
          Image.CLOCK5,
          Image.CLOCK6]

while True:
    display.show(clocks)