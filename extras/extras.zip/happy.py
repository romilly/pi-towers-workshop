from microbit import *

while True:
    display.show(Image.HAPPY)
    sleep(1000)
    display.show(Image.SAD)
    sleep(1000)