from microbit import *

display.show(Image.ALL_CLOCKS, loop=True)