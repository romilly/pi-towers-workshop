from microbit import *

while True:
    display.show(Image.CLOCK12)
    sleep(1000)
    display.show(Image.CLOCK1)
    sleep(1000)
    display.show(Image.CLOCK2)
    sleep(1000)
    display.show(Image.CLOCK3)
    sleep(1000)
    display.show(Image.CLOCK4)
    sleep(1000)
    display.show(Image.CLOCK5)
    sleep(1000)
    display.show(Image.CLOCK6)
    sleep(1000)